'use strict';
'require view';
'require rpc';
'require poll';
'require dom';
'require ui';


var callgetAwgInstances = rpc.declare({
	object: 'luci.amneziawg',
	method: 'getAwgInstances'
});

var callValidateAwgConfig = rpc.declare({
	object: 'luci.amneziawg',
	method: 'validateAwgConfig',
	params: [ 'config', 'filename' ]
});

var callImportAwgConfig = rpc.declare({
	object: 'luci.amneziawg',
	method: 'importAwgConfig',
	params: [ 'config', 'filename' ]
});

var callGetWarpAutoStatus = rpc.declare({
	object: 'luci.amneziawg',
	method: 'getWarpAutoStatus'
});

var callSaveWarpAutoSettings = rpc.declare({
	object: 'luci.amneziawg',
	method: 'saveWarpAutoSettings',
	params: [ 'settings', 'defer_service' ]
});

var callWarpAutoAction = rpc.declare({
	object: 'luci.amneziawg',
	method: 'warpAutoAction',
	params: [ 'action', 'id' ]
});

var callGetWarpAutoOperation = rpc.declare({
	object: 'luci.amneziawg',
	method: 'getWarpAutoOperation',
	params: [ 'operation_id' ]
});

var DEFAULT_WARP_SOURCE_URL = 'https://warp-generation.github.io';

function readTextFile(file) {
	return new Promise(function(resolve, reject) {
		var reader = new FileReader();
		reader.onload = function() { resolve(reader.result); };
		reader.onerror = function() { reject(new Error(_('Unable to read the selected file'))); };
		reader.readAsText(file, 'UTF-8');
	});
}

function boolValue(value) {
	return value === true || value === 1 || value === '1' || value === 'true';
}

function numberValue(value, fallback) {
	var number = +value;
	return isFinite(number) && number >= 0 ? number : fallback;
}

function autoTimestampToStr(value) {
	if (value == null || value === '' || value === 0 || value === '0')
		return '-';

	var timestamp = +value;
	if (isFinite(timestamp) && timestamp > 0) {
		if (timestamp > 100000000000)
			timestamp /= 1000;
		return timestampToStr(timestamp);
	}

	return String(value);
}

function redactAutoLog(value) {
	return String(value == null ? '' : value)
		.replace(/((?:private|preshared)key\s*=\s*)[^\s]+/ig, '$1[redacted]')
		.replace(/(\bi[1-5]\s*=\s*)[^\r\n]+/ig, '$1[redacted]');
}

function timestampToStr(timestamp) {
	if (timestamp < 1)
		return _('Never', 'No AmneziaWG peer handshake yet');

	var seconds = (Date.now() / 1000) - timestamp;
	var ago;

	if (seconds < 60)
		ago = _('%ds ago').format(seconds);
	else if (seconds < 3600)
		ago = _('%dm ago').format(seconds / 60);
	else if (seconds < 86401)
		ago = _('%dh ago').format(seconds / 3600);
	else
		ago = _('over a day ago');

	return (new Date(timestamp * 1000)).toUTCString() + ' (' + ago + ')';
}

function handleInterfaceDetails(iface) {
	ui.showModal(_('Instance Details'), [
		ui.itemlist(E([]), [
			_('Name'), iface.name,
			_('Public Key'), E('code', [ iface.public_key ]),
			_('Listen Port'), iface.listen_port,
			_('Firewall Mark'), iface.fwmark != 'off' ? iface.fwmark : E('em', _('none'))
		]),
		E('div', { 'class': 'right' }, [
			E('button', {
				'class': 'btn cbi-button',
				'click': ui.hideModal
			}, [ _('Dismiss') ])
		])
	]);
}

function handlePeerDetails(peer) {
	ui.showModal(_('Peer Details'), [
		ui.itemlist(E([]), [
			_('Description'), peer.name,
			_('Public Key'), E('code', [ peer.public_key ]),
			_('Endpoint'), peer.endpoint,
			_('Allowed IPs'), (Array.isArray(peer.allowed_ips) && peer.allowed_ips.length) ? peer.allowed_ips.join(', ') : E('em', _('none')),
			_('Received Data'), '%1024mB'.format(peer.transfer_rx),
			_('Transmitted Data'), '%1024mB'.format(peer.transfer_tx),
			_('Latest Handshake'), timestampToStr(+peer.latest_handshake),
			_('Keep-Alive'), (peer.persistent_keepalive != 'off') ? _('every %ds', 'AmneziaWG keep alive interval').format(+peer.persistent_keepalive) : E('em', _('none')),
		]),
		E('div', { 'class': 'right' }, [
			E('button', {
				'class': 'btn cbi-button',
				'click': ui.hideModal
			}, [ _('Dismiss') ])
		])
	]);
}


var ERROR_TRANSLATIONS = {
	'http_000': _('Connection timeout / no HTTP response'),
	'http_400': _('HTTP 400 Bad Request'),
	'http_403': _('HTTP 403 Forbidden'),
	'http_404': _('HTTP 404 Not Found'),
	'http_429': _('HTTP 429 Rate Limited'),
	'http_500': _('HTTP 500 Internal Server Error'),
	'http_502': _('HTTP 502 Bad Gateway'),
	'http_503': _('HTTP 503 Service Unavailable'),
	'missing_config': _('Configuration missing'),
	'invalid_config': _('Configuration invalid or corrupted'),
	'candidate_failed': _('Candidate failed isolated validation'),
	'fwmark': _('Firewall routing test failed (port conflict or rule error)'),
	'quic_failed': _('QUIC I1 handshake failed'),
	'handshake_timeout': _('WireGuard handshake timeout'),
	'health_timeout': _('Health check timeout')
};

function formatFriendlyError(err) {
	if (!err) return '';
	var str = String(err).trim();
	if (ERROR_TRANSLATIONS[str]) return ERROR_TRANSLATIONS[str] + ' (' + str + ')';
	return str.replace(/_/g, ' ');
}

function renderStatusBadge(status) {
	status = String(status || '-').toUpperCase();
	var badgeClass = 'cbi-badge';
	if (status === 'ACTIVE') badgeClass += ' cbi-badge-positive';
	else if (status === 'READY') badgeClass += ' cbi-badge-info';
	else if (status === 'FAILED') badgeClass += ' cbi-badge-negative';
	else badgeClass += ' cbi-badge-neutral';
	return E('span', { 'class': badgeClass, 'style': 'font-weight:600; padding:2px 8px; border-radius:3px;' }, [ status ]);
}

function renderHealthBadge(health) {
	if (!health || health === '-') return E('span', [ '-' ]);
	var badgeClass = 'cbi-badge';
	if (health === 'OK' || health === 'running') badgeClass += ' cbi-badge-positive';
	else if (health === 'FAIL' || health === 'failed' || health === 'stopped') badgeClass += ' cbi-badge-negative';
	else badgeClass += ' cbi-badge-neutral';
	return E('span', { 'class': badgeClass, 'style': 'font-weight:600; padding:2px 8px; border-radius:3px;' }, [ health ]);
}

function handleProfileDetails(entry, profileConfigs) {
	var createdStr = autoTimestampToStr(entry.created_at);
	var testedStr = autoTimestampToStr(entry.last_test);
	var healthStr = autoTimestampToStr(entry.last_health);
	var providerStr = entry.source_provider === 'native' ? _('Native (Cloudflare Registration API)') :
	                  entry.source_provider === 'remote' ? _('Remote (External Generator)') : (entry.source_provider || '-');
	var epSourceStr = entry.endpoint_source === 'cloudflare_registration' ? _('Cloudflare Registration API') :
	                  entry.endpoint_source === 'custom' ? _('Custom Endpoint Pool') : (entry.endpoint_source || '-');

	var conf = (profileConfigs && profileConfigs[entry.id]) || {};

	var iFieldsDesc = '-';
	if (Array.isArray(conf.i_fields) && conf.i_fields.length > 0) {
		iFieldsDesc = conf.i_fields.map(function(f) {
			return (f.name ? f.name.toUpperCase() : 'I') + ' (' + (f.length || 0) + ' bytes)';
		}).join(', ');
	}

	var items = [
		_('Identity'), E('hr', { 'style': 'margin:4px 0 8px 0; border:0; border-top:1px solid var(--border-color-medium);' }),
		_('Profile ID'), entry.id,
		_('Profile Name'), entry.profile || entry.id,
		_('Status'), renderStatusBadge(entry.status),
		_('Provider'), providerStr,
		_('Created'), createdStr,

		_('Endpoint & Connectivity'), E('hr', { 'style': 'margin:4px 0 8px 0; border:0; border-top:1px solid var(--border-color-medium);' }),
		_('Endpoint'), entry.endpoint ? E('code', [ entry.endpoint ]) : '-',
		_('Endpoint Source'), epSourceStr,
		_('Last Test (Latency)'), testedStr + (entry.latency_ms != null ? ' (' + entry.latency_ms + ' ms RTT)' : ''),
		_('Last Health Check'), healthStr,
		_('Consecutive Failures'), String(entry.failure_count || 0)
	];

	if (entry.last_error) {
		items.push(_('Last Error'), E('span', { 'class': 'cbi-badge cbi-badge-negative' }, [ formatFriendlyError(entry.last_error) ]));
	}

	if (conf.mtu || conf.jc || conf.h1) {
		var obfuscation = [];
		if (conf.jc) obfuscation.push('Jc=' + conf.jc + ' (Jmin=' + (conf.jmin || 0) + ', Jmax=' + (conf.jmax || 0) + ')');
		if (conf.s1) obfuscation.push('S1-S4: ' + [conf.s1, conf.s2, conf.s3, conf.s4].filter(Boolean).join('/'));
		if (conf.h1) obfuscation.push('H1-H4: ' + [conf.h1, conf.h2, conf.h3, conf.h4].filter(Boolean).join('/'));

		items.push(
			_('Configuration Parameters'), E('hr', { 'style': 'margin:4px 0 8px 0; border:0; border-top:1px solid var(--border-color-medium);' }),
			_('MTU'), conf.mtu ? String(conf.mtu) : _('default (1280)'),
			_('Obfuscation (J/S/H)'), obfuscation.length ? obfuscation.join(' · ') : _('standard'),
			_('Junk Packet Headers (I1-I5)'), iFieldsDesc
		);
	}

	ui.showModal(_('Profile Details: %s').format(entry.profile || entry.id), [
		ui.itemlist(E([]), items),
		E('div', { 'class': 'right', 'style': 'margin-top:1em' }, [
			E('button', {
				'class': 'btn cbi-button',
				'click': ui.hideModal
			}, [ _('Dismiss') ])
		])
	]);
}

function renderPeerTable(instanceName, peers) {
	var t = new L.ui.Table(
		[
			_('Peer'),
			_('Endpoint'),
			_('Data Received'),
			_('Data Transmitted'),
			_('Latest Handshake')
		],
		{
			id: 'peers-' + instanceName
		},
		E('em', [
			_('No peers connected')
		])
	);

	t.update(peers.map(function(peer) {
		return [
			[
				peer.name || '',
				E('div', {
					'style': 'cursor:pointer',
					'click': ui.createHandlerFn(this, handlePeerDetails, peer)
				}, [
					E('p', [
						peer.name ? E('span', [ peer.name ]) : E('em', [ _('Untitled peer') ])
					]),
					E('span', {
						'class': 'ifacebadge hide-sm',
						'data-tooltip': _('Public key: %h', 'Tooltip displaying full AmneziaWG peer public key').format(peer.public_key)
					}, [
						E('code', [ peer.public_key.replace(/^(.{5}).+(.{6})$/, '$1…$2') ])
					])
				])
			],
			peer.endpoint,
			[ +peer.transfer_rx, '%1024mB'.format(+peer.transfer_rx) ],
			[ +peer.transfer_tx, '%1024mB'.format(+peer.transfer_tx) ],
			[ +peer.latest_handshake, timestampToStr(+peer.latest_handshake) ]
		];
	}));

	return t.render();
}

return view.extend({
	showWarpAutoMessage: function(message, isError) {
		if (!this.autoMessageNode)
			return;

		dom.content(this.autoMessageNode, message ? E('span', {
			'class': isError ? 'error' : 'success'
		}, [ message ]) : []);
	},

	switchWarpTab: function(name) {
		Object.keys(this.warpTabs || {}).forEach(L.bind(function(key) {
			var tab = this.warpTabs[key];
			var active = key == name;

			tab.panel.style.display = active ? '' : 'none';
			tab.item.classList.toggle('cbi-tab', active);
			tab.item.classList.toggle('cbi-tab-disabled', !active);
			tab.link.style.fontWeight = active ? 'bold' : 'normal';
		}, this));
		if (this.warpTabHeading && this.warpTabs[name])
			dom.content(this.warpTabHeading, [ _('WARP Auto') + ' - ' + this.warpTabs[name].title ]);
	},

	renderWarpTabs: function(tabs) {
		var items = [];
		var panels = [];

		this.warpTabs = {};
		tabs.forEach(L.bind(function(tab, index) {
			var panel = E('div', {
				'class': 'cbi-section',
				'style': index ? 'display:none' : ''
			}, tab.content);
			var item = E('li', { 'class': index ? 'cbi-tab-disabled' : 'cbi-tab' });
			var link = E('a', {
				'href': '#',
				'style': index ? '' : 'font-weight:bold',
				'click': L.bind(function(event) {
					event.preventDefault();
					this.switchWarpTab(tab.id);
				}, this)
			}, [ tab.title ]);

			item.appendChild(link);
			this.warpTabs[tab.id] = {
				item: item,
				link: link,
				panel: panel,
				title: tab.title
			};
			items.push(item);
			panels.push(panel);
		}, this));

		this.warpTabHeading = E('h2', [ _('WARP Auto') + ' - ' + tabs[0].title ]);
		return E('div', { 'id': 'warp-auto-panel' }, [
			this.warpTabHeading,
			E('p', [ _('WARP profile manager and automatic failover.') ]),
			E('ul', { 'class': 'cbi-tabmenu' }, items),
			E('div', { 'role': 'status', 'aria-live': 'polite', 'style': 'margin-bottom:1em' }, [ this.autoMessageNode ])
		].concat(panels));
	},

	markWarpAutoSettingsDirty: function() {
		this.autoSettingsDirty = true;
	},

	setWarpAutoBusy: function(busy) {
		this.autoBusy = busy;

		(this.autoActionButtons || []).concat(this.autoPoolButtons || []).forEach(function(button) {
			button.disabled = busy;
		});

		if (this.autoSaveButton)
			this.autoSaveButton.disabled = busy;

		if (!busy && this.autoBootstrapButton)
			this.autoBootstrapButton.disabled = this.autoInterfaceState != 'missing';
	},

	getWarpAutoSettings: function() {
		var fields = this.autoFields;
		var resources = [];
		var known = {};

		String(fields.critical_resource.value || '').split(/[\r\n,]+/).forEach(function(value) {
			value = value.trim();
			if (value && !known[value]) {
				known[value] = true;
				resources.push(value);
			}
		});

		if (!resources.length)
			resources.push('youtube.com');

		return {
			interface: String(fields.interface_new.value || '').trim() || fields.interface.value,
			provider: fields.provider.value,
			batch_size: Math.floor(numberValue(fields.batch_size.value, 5)),
			native_sni: fields.native_sni.value.trim() || 'w3.org',
			native_quic_mode: fields.native_quic_mode.value,
			native_endpoint_mode: fields.native_endpoint_mode.value,
			native_batch_limit: Math.floor(numberValue(fields.batch_size.value, 5)),
			native_min_interval: Math.floor(numberValue(fields.native_min_interval.value, 900)),
			native_endpoints: fields.native_endpoints.value.split(/[\r\n,]+/).map(function(value) { return value.trim(); }).filter(Boolean),
			enabled: fields.enabled.checked ? '1' : '0',
			automatic_failover: fields.automatic_failover.checked ? '1' : '0',
			failover_cooldown: Math.floor(numberValue(fields.failover_cooldown.value, 10)),
			source_url: fields.source_url.value.trim() || DEFAULT_WARP_SOURCE_URL,
			refresh_interval: Math.floor(numberValue(fields.refresh_interval.value, 86400)),
			minimum_ready: Math.floor(numberValue(fields.minimum_ready.value, 2)),
			health_interval: Math.floor(numberValue(fields.health_interval.value, 60)),
			failure_threshold: Math.floor(numberValue(fields.failure_threshold.value, 3)),
			health_timeout: Math.floor(numberValue(fields.health_timeout.value, 10)),
			health_mode: fields.health_mode.checked ? 'strict' : 'direct',
			log_level: fields.log_level.value,
			critical_resource: resources,
			health_resolvers: String(fields.health_resolvers ? fields.health_resolvers.value : '').trim() || '1.1.1.1 8.8.8.8 9.9.9.9 77.88.8.8 77.88.8.1'
		};
	},

	setWarpAutoSettings: function(settings) {
		var fields = this.autoFields;
		var resources;

		if (!fields)
			return;

		settings = settings || {};
		this.setWarpAutoInterfaceChoices(this.autoKnownInterfaces || [], settings.interface || 'awg_warp');
		fields.interface_new.value = '';
		resources = settings.critical_resource || settings.critical_resources || [ 'youtube.com' ];
		if (!Array.isArray(resources))
			resources = String(resources).split(/[\r\n,]+/);

		fields.enabled.checked = boolValue(settings.enabled);
		fields.provider.value = settings.provider || 'remote';
		var bSize = numberValue(settings.batch_size != null ? settings.batch_size : settings.native_batch_limit, 5);
		if (fields.batch_size)
			fields.batch_size.value = bSize;
		if (fields.native_batch_limit)
			fields.native_batch_limit.value = bSize;
		if (this.autoGenerateButton)
			dom.content(this.autoGenerateButton, [ _('Generate profiles (%d)').format(bSize) ]);
		fields.native_sni.value = settings.native_sni || 'w3.org';
		fields.native_quic_mode.value = settings.native_quic_mode || 'dynamic';
		fields.native_endpoint_mode.value = settings.native_endpoint_mode || 'auto';
		fields.native_min_interval.value = numberValue(settings.native_min_interval, 900);
		fields.native_endpoints.value = Array.isArray(settings.native_endpoints) ? settings.native_endpoints.join('\n') : settings.native_endpoints || '';
		fields.automatic_failover.checked = settings.automatic_failover == null ? true : boolValue(settings.automatic_failover);
		fields.failover_cooldown.value = numberValue(settings.failover_cooldown, 10);
		fields.source_url.value = settings.source_url || DEFAULT_WARP_SOURCE_URL;
		fields.refresh_interval.value = numberValue(settings.refresh_interval, 86400);
		fields.minimum_ready.value = numberValue(settings.minimum_ready, 2);
		fields.health_interval.value = numberValue(settings.health_interval, 60);
		fields.failure_threshold.value = numberValue(settings.failure_threshold, 3);
		fields.health_timeout.value = numberValue(settings.health_timeout, 10);
		fields.health_mode.checked = settings.health_mode == null ? true : settings.health_mode == 'strict';
		fields.log_level.value = settings.log_level || 'info';
		fields.critical_resource.value = resources.filter(function(value) {
			return String(value).trim().length;
		}).join('\n') || 'youtube.com';
		if (fields.health_resolvers)
			fields.health_resolvers.value = settings.health_resolvers || '1.1.1.1 8.8.8.8 9.9.9.9 77.88.8.8 77.88.8.1';
		this.updateProviderFields();
	},

	updateProviderFields: function() {
		var native = this.autoFields.provider.value == 'native';
		if (this.nativeSettingsNode) this.nativeSettingsNode.style.display = native ? '' : 'none';
		if (this.remoteSettingsNode) this.remoteSettingsNode.style.display = native ? 'none' : '';
	},

	profileDownload: function(id, label) {
		return E('a', {
			'class': 'btn cbi-button cbi-button-action',
			'href': L.url('admin', 'services', 'amneziawg', 'download') + '?id=' + encodeURIComponent(id),
			'download': ''
		}, [ label || _('Download') ]);
	},

	setWarpAutoInterfaceChoices: function(interfaces, selected) {
		var field = this.autoFields && this.autoFields.interface;
		var names = [];
		var seen = {};

		(interfaces || []).forEach(function(name) {
			name = String(name || '');
			if (/^[A-Za-z][A-Za-z0-9_]{0,14}$/.test(name) && !seen[name]) {
				seen[name] = true;
				names.push(name);
			}
		});
		selected = String(selected || 'awg_warp');
		if (!seen[selected])
			names.unshift(selected);
		if (!field)
			return;
		dom.content(field, names.map(function(name) {
			return E('option', { 'value': name }, [ name ]);
		}));
		field.value = selected;
		this.autoTarget = selected;
	},

	getWarpAutoPool: function(state) {
		var pool = state.pool || state.configs || [];
		var result = [];

		if (Array.isArray(pool))
			return pool;

		for (var id in pool) {
			var entry = pool[id];
			if (entry && typeof entry == 'object') {
				if (!entry.id)
					entry.id = id;
				result.push(entry);
			}
		}

		return result;
	},

	renderWarpAutoRuntime: function(state) {
		var runtime = state.runtime || {};
		var pool = this.getWarpAutoPool(state);
		var service = runtime.service || runtime.state || (runtime.up === true ? 'running' : runtime.running === true ? 'running' : runtime.running === false ? 'stopped' : '-');
		var activeId = runtime.active_id || runtime.active || state.active_id || state.active || '';
		var interfaceState = runtime.interface_state || 'unknown';
		var bootstrapState = runtime.bootstrap_state || '-';
		var bootstrapError = runtime.bootstrap_error || '';
		var health = runtime.health || runtime.last_health || state.health || '-';
		var failures = runtime.consecutive_failures;
		var lastHealth = runtime.last_health || state.last_health;
		var lastFailover = runtime.last_failover;

		if (service && typeof service == 'object')
			service = service.status || service.state || '-';
		if (health && typeof health == 'object')
			health = health.status || health.result || '-';
		if (failures == null)
			failures = state.consecutive_failures;

		this.autoInterfaceState = interfaceState;
		if (this.autoBootstrapButton)
			this.autoBootstrapButton.disabled = this.autoBusy || interfaceState != 'missing' || bootstrapState == 'running';

		// Find active profile in pool
		var activeEntry = null;
		for (var i = 0; i < pool.length; i++) {
			if (pool[i].id === activeId || pool[i].active === true) {
				activeEntry = pool[i];
				break;
			}
		}

		// Check for state discrepancy between configured profile and actual kernel peer
		var discrepancy = false;
		var discrepancyMsg = '';
		if (activeEntry && runtime.actual_endpoint && activeEntry.endpoint) {
			if (activeEntry.endpoint !== runtime.actual_endpoint) {
				discrepancy = true;
				discrepancyMsg = _('Discrepancy: active profile specifies %s but kernel interface is connected to %s.').format(activeEntry.endpoint, runtime.actual_endpoint);
			}
		}
		if (runtime.actual_peer_desc && activeId && runtime.actual_peer_desc !== activeId) {
			discrepancy = true;
			discrepancyMsg = _('Discrepancy: configured interface peer is %s but active profile is %s.').format(runtime.actual_peer_desc, activeId);
		}

		// 1. Compact 4-6 indicator grid using native LuCI theme classes
		var trafficRx = runtime.actual_rx != null ? '%1024mB'.format(+runtime.actual_rx) : '-';
		var trafficTx = runtime.actual_tx != null ? '%1024mB'.format(+runtime.actual_tx) : '-';
		var handshakeStr = runtime.actual_handshake ? timestampToStr(+runtime.actual_handshake) : _('No handshake yet');
		var failoverStr = lastFailover ? autoTimestampToStr(lastFailover) : _('Never');

		var gridStyle = 'display:grid; grid-template-columns:repeat(auto-fit, minmax(170px, 1fr)); gap:12px; margin-bottom:16px;';
		var cardStyle = 'background-color:var(--background-color-low); border:1px solid var(--border-color-medium); border-radius:4px; padding:10px 14px;';
		var labelStyle = 'font-size:11px; text-transform:uppercase; color:var(--text-color-medium); font-weight:bold; margin-bottom:4px;';
		var valueStyle = 'font-size:15px; font-weight:600; word-break:break-all; color:var(--text-color-high);';

		var makeCard = function(title, content) {
			return E('div', { 'style': cardStyle }, [
				E('div', { 'style': labelStyle }, [ title ]),
				E('div', { 'style': valueStyle }, [ content ])
			]);
		};

		var dashboard = E('div', { 'style': gridStyle }, [
			makeCard(_('Service'), renderHealthBadge(service)),
			makeCard(_('Interface'), E('span', [
				(runtime.interface || 'YTwarp') + ' ',
				E('small', { 'style': 'font-weight:normal; opacity:.8;' }, [ '(' + (interfaceState === 'present' ? _('up') : interfaceState) + ')' ])
			])),
			makeCard(_('Health Gate'), renderHealthBadge(health)),
			makeCard(_('Last Handshake'), E('span', { 'style': 'font-size:13px;' }, [ handshakeStr ])),
			makeCard(_('Traffic (RX / TX)'), E('span', { 'style': 'font-size:13px;' }, [ trafficRx + ' / ' + trafficTx ])),
			makeCard(_('Failover Status'), E('span', { 'style': 'font-size:13px;' }, [
				(failures > 0 ? E('span', { 'class': 'cbi-badge cbi-badge-negative' }, [ failures + ' fail' ]) : _('Stable (0 fail)')),
				' · ',
				failoverStr
			]))
		]);

		// 2. Active Connection dedicated card using native theme background & accent
		var activeConnCard = null;
		if (activeEntry) {
			var activeProvider = activeEntry.source_provider === 'native' ? _('Native (Cloudflare)') :
			                     activeEntry.source_provider === 'remote' ? _('Remote') : (activeEntry.source_provider || '-');
			var activeEpSource = activeEntry.endpoint_source === 'cloudflare_registration' ? _('Registration API') :
			                     activeEntry.endpoint_source === 'custom' ? _('Custom Pool') : (activeEntry.endpoint_source || '-');

			var detailsBtn = E('button', {
				'class': 'btn cbi-button',
				'style': 'margin-left:6px;',
				'click': L.bind(function(ev) {
					ev.preventDefault();
					handleProfileDetails(activeEntry, state.profile_configs);
				}, this)
			}, [ _('Details') ]);

			activeConnCard = E('div', {
				'class': 'cbi-section',
				'style': 'background-color:var(--background-color-low); border:1px solid var(--border-color-medium); border-left:4px solid var(--success-color-high, #27ae60); padding:12px 16px; margin-bottom:16px;'
			}, [
				E('div', { 'style': 'display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap;' }, [
					E('div', [
						E('h4', { 'style': 'margin:0 0 6px 0; font-size:16px; color:var(--text-color-high);' }, [
							_('Active Connection: '),
							E('strong', [ activeEntry.profile || activeEntry.id ]),
							' ',
							renderStatusBadge(activeEntry.status)
						]),
						E('div', { 'style': 'font-size:13px; color:var(--text-color-medium);' }, [
							E('span', [ _('Provider: '), E('strong', { 'style': 'color:var(--text-color-high);' }, [ activeProvider ]), ' (' + activeEpSource + ')' ]),
							' · ',
							E('span', [ _('Endpoint: '), E('code', [ runtime.actual_endpoint || activeEntry.endpoint || '-' ]) ]),
							(activeEntry.latency_ms != null ? E('span', [ ' · ', _('RTT: '), activeEntry.latency_ms + ' ms' ]) : '')
						])
					]),
					E('div', { 'style': 'margin-top:6px;' }, [
						this.profileDownload('active', _('Download .conf')),
						detailsBtn
					])
				]),
				discrepancy ? E('div', {
					'class': 'alert-message warning',
					'style': 'margin-top:10px; margin-bottom:0;'
				}, [ discrepancyMsg ]) : ''
			]);
		} else {
			activeConnCard = E('div', {
				'class': 'cbi-section',
				'style': 'background-color:var(--background-color-low); border:1px solid var(--border-color-medium); border-left:4px solid var(--warn-color-high, #f39c12); padding:12px 16px; margin-bottom:16px;'
			}, [
				E('strong', { 'style': 'color:var(--text-color-high);' }, [ _('No active WARP profile assigned.') ]),
				E('p', { 'style': 'margin:4px 0 0 0; font-size:13px; color:var(--text-color-medium);' }, [
					_('Choose a READY profile from the pool below and click "Activate", or wait for automatic selection.')
				])
			]);
		}

		var batchBanner = null;
		var bState = runtime.batch_state;
		if (bState === 'running' || bState === 'complete' || bState === 'failed') {
			var bClass = bState === 'running' ? 'alert-message info' :
			             bState === 'failed' ? 'alert-message warning' : 'alert-message notice';
			var bProvStr = runtime.batch_provider === 'native' ? _('Native') :
			               runtime.batch_provider === 'remote' ? _('Remote') : (runtime.batch_provider || '');
			var bTitle = bState === 'running' ? _('Profile generation in progress (%s)…').format(bProvStr) :
			             bState === 'failed' ? _('Profile generation interrupted (%s)').format(bProvStr) :
			             _('Profile generation completed (%s)').format(bProvStr);
			var bDetails = [];
			if (runtime.batch_requested)
				bDetails.push(_('Requested: %d').format(runtime.batch_requested));
			if (runtime.batch_ready != null)
				bDetails.push(_('Ready: %d').format(runtime.batch_ready));
			if (runtime.batch_failed != null && runtime.batch_failed > 0)
				bDetails.push(_('Failed: %d').format(runtime.batch_failed));

			batchBanner = E('div', { 'class': bClass, 'style': 'margin-bottom:16px;' }, [
				E('strong', [ bTitle ]),
				runtime.batch_message ? E('div', { 'style': 'margin-top:4px; font-size:13px;' }, [ runtime.batch_message ]) : '',
				bDetails.length ? E('div', { 'style': 'margin-top:4px; font-size:12px; opacity:0.85;' }, [ bDetails.join(' · ') ]) : ''
			]);
		}

		dom.content(this.autoRuntimeNode, [ dashboard, activeConnCard, batchBanner ].filter(Boolean));
	},

	renderWarpAutoPool: function(state) {
		var pool = this.getWarpAutoPool(state);
		this.autoPoolButtons = [];
		var filter = this.poolFilter || 'all';

		// Calculate pool health summary counts
		var total = pool.length;
		var readyCount = 0;
		var activeCount = 0;
		var failedCount = 0;
		var nativeCount = 0;
		var remoteCount = 0;

		pool.forEach(function(entry) {
			var st = String(entry.status || entry.state || '').toUpperCase();
			if (st === 'ACTIVE') activeCount++;
			else if (st === 'READY') readyCount++;
			else if (st === 'FAILED') failedCount++;
			if (entry.source_provider === 'native') nativeCount++;
			else if (entry.source_provider === 'remote') remoteCount++;
		});

		var configuredProvider = (state.settings && state.settings.provider) || 'remote';
		var minReady = (state.settings && state.settings.minimum_ready != null) ? state.settings.minimum_ready : 2;
		var poolStatusText = readyCount >= minReady ? _('Pool healthy') : _('Pool degraded (under minimum READY threshold)');
		var poolStatusBadge = readyCount >= minReady ? 'cbi-badge cbi-badge-positive' : 'cbi-badge cbi-badge-negative';

		var providerSemanticsInfo = configuredProvider === 'native' && remoteCount > 0
			? E('div', { 'class': 'cbi-value-description', 'style': 'margin-top:4px; font-size:12px; color:var(--text-color-medium);' }, [
				_('Configured provider is Native. Existing Remote profiles in pool serve as valid standby fallback until replaced or refreshed.')
			]) : '';

		var summaryHeader = E('div', {
			'style': 'display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; margin-bottom:10px; gap:8px;'
		}, [
			E('div', [
				E('span', { 'class': poolStatusBadge, 'style': 'font-weight:600; padding:3px 10px; margin-right:8px;' }, [ poolStatusText ]),
				E('span', { 'style': 'color:var(--text-color-medium); font-size:13px;' }, [
					_('Total: %d · Active: %d · READY: %d (min %d) · Failed: %d').format(total, activeCount, readyCount, minReady, failedCount)
				]),
				providerSemanticsInfo
			]),
			// Filter buttons: All | Native | Remote
			E('div', { 'class': 'btn-group' }, [
				E('button', {
					'class': 'btn cbi-button' + (filter === 'all' ? ' cbi-button-action' : ''),
					'click': L.bind(function(ev) {
						ev.preventDefault();
						this.poolFilter = 'all';
						this.renderWarpAutoPool(state);
					}, this)
				}, [ _('All (%d)').format(total) ]),
				E('button', {
					'class': 'btn cbi-button' + (filter === 'native' ? ' cbi-button-action' : ''),
					'click': L.bind(function(ev) {
						ev.preventDefault();
						this.poolFilter = 'native';
						this.renderWarpAutoPool(state);
					}, this)
				}, [ _('Native (%d)').format(nativeCount) ]),
				E('button', {
					'class': 'btn cbi-button' + (filter === 'remote' ? ' cbi-button-action' : ''),
					'click': L.bind(function(ev) {
						ev.preventDefault();
						this.poolFilter = 'remote';
						this.renderWarpAutoPool(state);
					}, this)
				}, [ _('Remote (%d)').format(remoteCount) ])
			])
		]);

		var filteredPool = pool.filter(function(entry) {
			if (filter === 'native') return entry.source_provider === 'native';
			if (filter === 'remote') return entry.source_provider === 'remote';
			return true;
		});

		var rows = filteredPool.map(L.bind(function(entry) {
			var id = String(entry.id || entry.fingerprint || entry.name || '-');
			var profile = entry.profile || entry.name || id;
			var status = String(entry.status || entry.state || '-').toUpperCase();
			var endpoint = entry.endpoint || '-';
			var lastTest = autoTimestampToStr(entry.last_test || entry.tested_at);
			var latency = entry.latency_ms == null ? '-' : String(entry.latency_ms) + ' ms';
			var failures = entry.failure_count == null ? '0' : String(entry.failure_count);

			var providerStr = entry.source_provider === 'native' ? _('Native') :
			                  entry.source_provider === 'remote' ? _('Remote') : (entry.source_provider || '-');
			var epSourceStr = entry.endpoint_source === 'cloudflare_registration' ? _('CF Reg') :
			                  entry.endpoint_source === 'custom' ? _('Custom') : (entry.endpoint_source || '-');

			var actions = [];
			if (status == 'READY' || status == 'FAILED') {
				var action = status == 'READY' ? 'activate' : 'retest';
				var button = E('button', {
					'class': 'btn cbi-button cbi-button-action',
					'click': L.bind(function(event) {
						event.preventDefault();
						return this.runWarpAutoAction(action, id);
					}, this)
				}, [ status == 'READY' ? _('Activate') : _('Retest') ]);
				button.disabled = !!this.autoBusy;
				this.autoPoolButtons.push(button);
				actions.push(button, ' ');
			}
			actions.push(this.profileDownload(id));

			var detailsBtn = E('button', {
				'class': 'btn cbi-button',
				'click': L.bind(function(event) {
					event.preventDefault();
					handleProfileDetails(entry, state.profile_configs);
				}, this)
			}, [ _('Details') ]);
			actions.push(' ', detailsBtn);

			var profileLink = E('a', {
				'href': '#',
				'style': 'font-weight:600; cursor:pointer;',
				'title': _('Click for details'),
				'click': L.bind(function(ev) {
					ev.preventDefault();
					handleProfileDetails(entry, state.profile_configs);
				}, this)
			}, [ String(profile) ]);

			return E('tr', [
				E('td', [ profileLink ]),
				E('td', [ providerStr ]),
				E('td', [ epSourceStr ]),
				E('td', [ E('code', [ String(endpoint) ]) ]),
				E('td', [ renderStatusBadge(status) ]),
				E('td', [ lastTest ]),
				E('td', [ latency ]),
				E('td', [ failures ]),
				E('td', { 'style': 'white-space:nowrap' }, actions)
			]);
		}, this));

		if (!rows.length)
			rows.push(E('tr', [ E('td', { 'colspan': 9 }, [ E('em', [ _('No profiles match current filter.') ]) ]) ]));

		dom.content(this.autoPoolNode, E('div', [
			summaryHeader,
			E('table', { 'class': 'table cbi-section-table' }, [
				E('tr', { 'class': 'tr table-titles' }, [
					E('th', { 'class': 'th' }, [ _('Profile') ]),
					E('th', { 'class': 'th' }, [ _('Provider') ]),
					E('th', { 'class': 'th' }, [ _('Source') ]),
					E('th', { 'class': 'th' }, [ _('Endpoint') ]),
					E('th', { 'class': 'th' }, [ _('State') ]),
					E('th', { 'class': 'th' }, [ _('Last test') ]),
					E('th', { 'class': 'th' }, [ _('Latency (RTT)') ]),
					E('th', { 'class': 'th' }, [ _('Failures') ]),
					E('th', { 'class': 'th' }, [ _('Actions') ])
				])
			].concat(rows))
		]));
	},

	renderWarpAutoLogs: function(state) {
		var logs = state.logs || state.recent_logs || [];
		var filterLevel = this.logsFilterLevel || 'all';

		var lines = [];
		if (typeof logs == 'string') {
			lines = logs.split(/\r?\n/).filter(Boolean);
		} else if (Array.isArray(logs)) {
			lines = logs.filter(Boolean);
		}

		lines = lines.slice(-80).map(redactAutoLog);

		var monthMap = { Jan:'01', Feb:'02', Mar:'03', Apr:'04', May:'05', Jun:'06', Jul:'07', Aug:'08', Sep:'09', Oct:'10', Nov:'11', Dec:'12' };

		var parsedLogs = [];
		lines.forEach(function(raw, idx) {
			var text = String(raw).trim();
			if (!text) return;

			var timeStr = '';
			var ts = idx;
			var cleanText = text;

			// Parse standard syslog timestamp: "Sat Sep  5 20:18:55 2026 user.warn awg-warp-auto: ..."
			var m = text.match(/^([A-Za-z]{3})\s+([A-Za-z]{3})\s+(\d+)\s+(\d{2}:\d{2}:\d{2})\s+(\d{4})\s+(user|daemon)\.([a-z]+)\s+awg-warp-auto:\s*(.*)$/);
			if (m) {
				var month = monthMap[m[2]] || '01';
				var day = m[3].length === 1 ? '0' + m[3] : m[3];
				timeStr = m[5] + '-' + month + '-' + day + ' ' + m[4];
				ts = Date.parse(m[5] + '-' + month + '-' + day + 'T' + m[4] + 'Z') || idx;
				cleanText = m[8];
			} else {
				cleanText = text.replace(/^[A-Za-z]{3}\s+[A-Za-z]{3}\s+\d+\s+\d+:\d+:\d+\s+\d{4}\s+/, '');
				cleanText = cleanText.replace(/^(daemon|user)\.(info|notice|warn|err|debug)\s+awg-warp-auto:\s*/, '');
			}

			var level = 'info';
			if (/daemon\.err|user\.err|\berror\b/i.test(text)) level = 'error';
			else if (/daemon\.warn|user\.warn|\bwarning\b|\brollback\b|\bfailed\b/i.test(text)) level = 'warn';
			else if (/daemon\.debug|user\.debug|\bdebug\b/i.test(text)) level = 'debug';

			parsedLogs.push({ raw: text, timeStr: timeStr, timestamp: ts, level: level, message: cleanText, seq: idx });
		});

		// Sort descending: NEWEST events at the top
		parsedLogs.sort(function(a, b) {
			if (b.timestamp !== a.timestamp) return b.timestamp - a.timestamp;
			return b.seq - a.seq;
		});

		var filteredLogs = parsedLogs.filter(function(item) {
			if (filterLevel === 'all') return true;
			if (filterLevel === 'warn') return item.level === 'warn' || item.level === 'error';
			if (filterLevel === 'error') return item.level === 'error';
			return true;
		});

		var logRows = filteredLogs.map(function(item) {
			var badgeClass = 'cbi-badge';
			if (item.level === 'error') badgeClass += ' cbi-badge-negative';
			else if (item.level === 'warn') badgeClass += ' cbi-badge-neutral';
			else if (item.level === 'info') badgeClass += ' cbi-badge-info';
			else badgeClass += ' cbi-badge-neutral';

			return E('div', {
				'style': 'font-family:var(--font-mono, monospace); font-size:12px; margin-bottom:4px; line-height:1.5; border-bottom:1px solid var(--border-color-low); padding-bottom:3px; color:var(--text-color-high);'
			}, [
				item.timeStr ? E('span', { 'style': 'color:var(--text-color-medium); margin-right:8px;' }, [ item.timeStr ]) : '',
				E('span', { 'class': badgeClass, 'style': 'font-size:10px; font-weight:bold; padding:2px 6px; margin-right:8px; text-transform:uppercase;' }, [ item.level ]),
				E('span', [ item.message ])
			]);
		});

		var controls = E('div', { 'style': 'display:flex; justify-content:space-between; align-items:center; margin-bottom:10px; flex-wrap:wrap; gap:8px;' }, [
			E('div', [
				E('span', { 'style': 'font-weight:bold; margin-right:8px; color:var(--text-color-high);' }, [ _('Filter Level:') ]),
				E('div', { 'class': 'btn-group' }, [
					E('button', {
						'class': 'btn cbi-button' + (filterLevel === 'all' ? ' cbi-button-action' : ''),
						'click': L.bind(function(ev) {
							ev.preventDefault();
							this.logsFilterLevel = 'all';
							this.renderWarpAutoLogs(state);
						}, this)
					}, [ _('All') ]),
					E('button', {
						'class': 'btn cbi-button' + (filterLevel === 'warn' ? ' cbi-button-action' : ''),
						'click': L.bind(function(ev) {
							ev.preventDefault();
							this.logsFilterLevel = 'warn';
							this.renderWarpAutoLogs(state);
						}, this)
					}, [ _('Warnings & Errors') ]),
					E('button', {
						'class': 'btn cbi-button' + (filterLevel === 'error' ? ' cbi-button-action' : ''),
						'click': L.bind(function(ev) {
							ev.preventDefault();
							this.logsFilterLevel = 'error';
							this.renderWarpAutoLogs(state);
						}, this)
					}, [ _('Errors Only') ])
				])
			]),
			E('button', {
				'class': 'btn cbi-button',
				'click': L.bind(function(ev) {
					ev.preventDefault();
					this.updateWarpAuto();
				}, this)
			}, [ _('Refresh Logs') ])
		]);

		dom.content(this.autoLogsNode, [
			controls,
			E('div', {
				'style': 'max-height:24em; overflow:auto; background-color:var(--background-color-low); border:1px solid var(--border-color-medium); border-radius:4px; padding:10px;'
			}, logRows.length ? logRows : [ E('em', [ _('No logs match selected filter.') ]) ])
		]);
	},

	updateWarpAuto: function() {
		return callGetWarpAutoStatus().then(L.bind(function(state) {
			state = state || {};
			if (state.ok === false)
				throw new Error(state.error || _('Unable to read WARP Auto status'));

			this.lastAutoState = state;
			this.autoKnownInterfaces = (state.runtime && state.runtime.available_interfaces) || [];
			if (!this.autoSettingsLoaded || !this.autoSettingsDirty)
				this.setWarpAutoSettings(state.settings);
			this.autoSettingsLoaded = true;
			this.renderWarpAutoRuntime(state);
			this.renderWarpAutoPool(state);
			this.renderWarpAutoLogs(state);

			// Check for pending background activation from session
			if (!this.activationPollingActive) {
				try {
					var raw = sessionStorage.getItem('warp_auto_active_op');
					if (raw) {
						var parsed = JSON.parse(raw);
						if (parsed && parsed.op_id && (Date.now() - (parsed.start || 0) < 60000)) {
							callGetWarpAutoOperation(parsed.op_id).then(L.bind(function(opRes) {
								var op = opRes && opRes.operation;
								if (op && (op.status === 'running' || op.status === 'waiting')) {
									if (!this.activationPollingActive) {
										this.attachActivationModal(parsed.op_id, parsed.id);
									}
								} else {
									sessionStorage.removeItem('warp_auto_active_op');
								}
							}, this)).catch(function() {
								sessionStorage.removeItem('warp_auto_active_op');
							});
						} else {
							sessionStorage.removeItem('warp_auto_active_op');
						}
					}
				} catch(e) {}
			}
		}, this)).catch(L.bind(function(error) {
			this.showWarpAutoMessage(error.message || _('Unable to read WARP Auto status'), true);
		}, this));
	},

	saveWarpAutoSettings: function() {
		var settings = this.getWarpAutoSettings();

		this.setWarpAutoBusy(true);
		this.showWarpAutoMessage(_('Saving WARP Auto settings…'));

		return callSaveWarpAutoSettings(settings, '0').then(L.bind(function(result) {
			if (!result || result.ok === false)
				throw new Error(result && result.error || _('Unable to save WARP Auto settings'));

			this.autoSettingsDirty = false;
			this.showWarpAutoMessage(result.message || _('WARP Auto settings saved.'));
			return this.updateWarpAuto();
		}, this)).catch(L.bind(function(error) {
			this.showWarpAutoMessage(error.message || _('Unable to save WARP Auto settings'), true);
			ui.addNotification(null, E('p', [ error.message || _('Unable to save WARP Auto settings') ]), 'error');
		}, this)).then(L.bind(function(result) {
			this.setWarpAutoBusy(false);
			return result;
		}, this));
	},

	attachActivationModal: function(operationId, id) {
		var stepApplying = E('li', { 'style': 'margin-bottom:8px;' }, [
			E('span', { 'class': 'spinning', 'style': 'margin-right:8px;' }, '⏳'),
			_('Applying configuration to network interface…')
		]);
		var stepHealth = E('li', { 'style': 'margin-bottom:8px; opacity:0.5;' }, [
			E('span', { 'style': 'margin-right:8px;' }, '⚪'),
			_('Running connectivity health check (YouTube/DNS)…')
		]);
		var stepFinalize = E('li', { 'style': 'margin-bottom:8px; opacity:0.5;' }, [
			E('span', { 'style': 'margin-right:8px;' }, '⚪'),
			_('Finalizing activation and committing state…')
		]);

		var checklistNode = E('ul', { 'style': 'list-style:none; padding-left:0; margin:16px 0;' }, [
			stepApplying, stepHealth, stepFinalize
		]);

		var statusTextNode = E('p', { 'style': 'color:var(--text-color-medium); margin-top:8px;' }, [
			_('Please wait, profile activation and verification may take up to 40 seconds.')
		]);

		var modalContent = E('div', [
			E('p', [ _('Activating AmneziaWG profile %s…').format(id || _('profile')) ]),
			checklistNode,
			statusTextNode
		]);

		ui.showModal(_('Profile Activation'), [ modalContent ]);
		this.setWarpAutoBusy(true);

		try { poll.stop(); } catch(e) {}

		var startTime = Date.now();
		var timeoutMs = 60000;

		try {
			sessionStorage.setItem('warp_auto_active_op', JSON.stringify({ op_id: operationId, id: id, start: startTime }));
		} catch(e) {}

		var setStepState = function(node, state, text) {
			node.style.opacity = '1';
			var icon = state === 'active' ? '⏳' : state === 'done' ? '✓' : state === 'failed' ? '✗' : '⚪';
			var iconClass = state === 'active' ? 'spinning' : '';
			dom.content(node, [
				E('span', { 'class': iconClass, 'style': 'margin-right:8px; font-weight:bold;' }, icon),
				text
			]);
		};

		var cleanup = L.bind(function() {
			try { sessionStorage.removeItem('warp_auto_active_op'); } catch(e) {}
			this.activationPollingActive = false;
			try { poll.start(); } catch(e) {}
			this.setWarpAutoBusy(false);
			this.updateWarpAuto();
		}, this);

		this.activationPollingActive = true;

		return new Promise(L.bind(function(resolve, reject) {
			var pollInterval = setInterval(L.bind(function() {
				if (Date.now() - startTime > timeoutMs) {
					clearInterval(pollInterval);
					callGetWarpAutoStatus().then(L.bind(function(st) {
						ui.hideModal();
						cleanup();
						var activeNow = (st && st.runtime && st.runtime.active_id) || (st && st.active_id);
						if (activeNow === id) {
							ui.addNotification(null, E('p', [ _('Profile %s activated successfully.').format(id) ]), 'info');
						} else {
							ui.addNotification(null, E('p', [ _('Activation timed out. Previous profile remained active.') ]), 'warning');
						}
						resolve();
					}, this)).catch(function(err) {
						ui.hideModal();
						cleanup();
						reject(err);
					});
					return;
				}

				callGetWarpAutoOperation(operationId).then(L.bind(function(opRes) {
					var op = (opRes && opRes.operation) || null;
					if (!op) return;

					if (op.step === 'applying' || op.step === 'waiting') {
						setStepState(stepApplying, 'active', _('Applying configuration to network interface…'));
					} else if (op.step === 'health_check') {
						setStepState(stepApplying, 'done', _('Configuration applied to network interface'));
						setStepState(stepHealth, 'active', _('Running connectivity health check (YouTube/DNS)…'));
					} else if (op.step === 'rolling_back') {
						setStepState(stepApplying, 'done', _('Configuration applied to network interface'));
						setStepState(stepHealth, 'failed', _('Health check failed (%s)').format(op.error || _('connectivity error')));
						setStepState(stepFinalize, 'active', _('Rolling back to previous working profile…'));
					}

					if (op.status === 'success') {
						clearInterval(pollInterval);
						setStepState(stepApplying, 'done', _('Configuration applied to network interface'));
						setStepState(stepHealth, 'done', _('Connectivity health check passed'));
						setStepState(stepFinalize, 'done', _('Profile activated successfully'));
						setTimeout(function() {
							ui.hideModal();
							cleanup();
							ui.addNotification(null, E('p', [ _('Profile %s activated successfully!').format(id) ]), 'info');
							resolve();
						}, 800);
					} else if (op.status === 'rolled_back') {
						clearInterval(pollInterval);
						setStepState(stepFinalize, 'failed', _('Rolled back: %s').format(op.error || _('health check failed')));
						setTimeout(function() {
							ui.hideModal();
							cleanup();
							ui.addNotification(null, E('p', [ _('Activation failed (%s). Previous profile restored.').format(op.error || 'health check failed') ]), 'warning');
							resolve();
						}, 1200);
					} else if (op.status === 'failed') {
						clearInterval(pollInterval);
						setStepState(stepFinalize, 'failed', _('Failed: %s').format(op.error || _('unknown error')));
						setTimeout(function() {
							ui.hideModal();
							cleanup();
							ui.addNotification(null, E('p', [ _('Activation error: %s').format(op.error || 'unknown error') ]), 'error');
							reject(new Error(op.error));
						}, 1200);
					}
				}, this)).catch(function(err) {
					// Ignored transient read error during polling
				});
			}, this), 1000);
		}, this));
	},

	runActivationFlow: function(id) {
		return callWarpAutoAction('activate', id).then(L.bind(function(res) {
			if (!res || res.ok === false)
				throw new Error((res && res.error) || _('Failed to start profile activation'));

			return this.attachActivationModal(res.operation_id, id);
		}, this)).catch(L.bind(function(error) {
			try { sessionStorage.removeItem('warp_auto_active_op'); } catch(e) {}
			ui.hideModal();
			try { poll.start(); } catch(e) {}
			this.setWarpAutoBusy(false);
			this.showWarpAutoMessage(error.message || _('Activation failed'), true);
			ui.addNotification(null, E('p', [ error.message || _('Activation failed') ]), 'error');
		}, this));
	},

	runWarpAutoAction: function(action, profileId) {
		/* RPC declares id as a string. Send an empty string for actions that
		 * do not target a pool entry, otherwise ubus rejects the request before
		 * the backend can dispatch refresh/test_all/rollback. */
		var id = profileId || '';
		var actionNames = {
			refresh: _('Refreshing configurations…'),
			batch: _('Generating profiles batch…'),
			test_all: _('Testing configurations…'),
			activate: _('Activating selected profile…'),
			retest: _('Retesting profile…'),
			native_test: _('Generating and testing Native profile…'),
			force_replenish: _('Replenishing profile pool (force)…'),
			rollback: _('Rolling back profile…'),
			bootstrap: _('Creating and testing WARP interface…')
		};

		if (action == 'activate') {
			if (!id) {
				this.showWarpAutoMessage(_('Select a READY profile first.'), true);
				return Promise.resolve();
			}
			return this.runActivationFlow(id);
		}

		this.setWarpAutoBusy(true);
		this.showWarpAutoMessage(actionNames[action] || _('Running WARP Auto action…'));

		var request = action == 'bootstrap' || action == 'native_test' || action == 'batch'
			? callSaveWarpAutoSettings(this.getWarpAutoSettings(), '1').then(L.bind(function(saved) {
				if (!saved || saved.ok === false)
					throw new Error(saved && saved.error || _('Unable to save WARP Auto settings'));
				this.autoSettingsDirty = false;
				return callWarpAutoAction(action, id);
			}, this))
			: callWarpAutoAction(action, id);

		return request.then(L.bind(function(result) {
			if (!result || result.ok === false)
				throw new Error(result && result.error || _('WARP Auto action failed'));

			this.showWarpAutoMessage(result.message || (action == 'bootstrap'
				? _('Initial setup started. Follow its state below.')
				: _('WARP Auto action completed.')));
			return this.updateWarpAuto();
		}, this)).catch(L.bind(function(error) {
			this.showWarpAutoMessage(error.message || _('WARP Auto action failed'), true);
			ui.addNotification(null, E('p', [ error.message || _('WARP Auto action failed') ]), 'error');
		}, this)).then(L.bind(function(result) {
			this.setWarpAutoBusy(false);
			return result;
		}, this));
	},

	renderWarpAuto: function() {
		var fields = {};
		var dirty = L.bind(this.markWarpAutoSettingsDirty, this);
		var makeInput = function(name, type, attrs) {
			attrs = attrs || {};
			attrs.type = type;
			attrs.name = name;
			attrs['class'] = attrs['class'] || 'cbi-input-text';
			var input = E('input', attrs);
			input.addEventListener('input', dirty);
			input.addEventListener('change', dirty);
			fields[name] = input;
			return input;
		};
		var makeRow = function(label, control, help) {
			return E('div', { 'class': 'cbi-value' }, [
				E('label', { 'class': 'cbi-value-title' }, [ label ]),
				E('div', { 'class': 'cbi-value-field' }, [
					control,
					help ? E('div', { 'class': 'cbi-value-description' }, [ help ]) : ''
				])
			]);
		};
		var enabled = makeInput('enabled', 'checkbox', { 'class': 'cbi-input-checkbox' });
		var failover = makeInput('automatic_failover', 'checkbox', { 'class': 'cbi-input-checkbox' });
		var failoverCooldown = makeInput('failover_cooldown', 'number', { 'min': 5, 'max': 3600, 'step': 1 });
		var target = E('select', { 'class': 'cbi-input-select', 'name': 'interface' }, []);
		target.addEventListener('change', dirty);
		fields.interface = target;
		var targetNew = makeInput('interface_new', 'text', {
			'placeholder': _('new interface name'),
			'pattern': '[A-Za-z][A-Za-z0-9_]{0,14}',
			'title': _('Letters, digits and underscore; 15 characters maximum')
		});
		var source = makeInput('source_url', 'url', {
			'placeholder': DEFAULT_WARP_SOURCE_URL,
			'style': 'width:100%; max-width:40em'
		});
		var provider = E('select', { 'class': 'cbi-input-select', 'name': 'provider' }, [
			E('option', { 'value': 'remote' }, [ _('Remote') ]),
			E('option', { 'value': 'native' }, [ _('Native') ])
		]);
		fields.provider = provider;
		provider.addEventListener('change', dirty);
		provider.addEventListener('change', L.bind(this.updateProviderFields, this));
		var nativeSni = makeInput('native_sni', 'text', { 'placeholder': 'w3.org', 'maxlength': 253 });
		var nativeQuicMode = E('select', { 'class': 'cbi-input-select', 'name': 'native_quic_mode' }, [
			E('option', { 'value': 'dynamic' }, [ _('Dynamic local SNI I1 (Recommended)') ]),
			E('option', { 'value': 'fallback' }, [ _('Compatibility preset (Fallback only)') ])
		]);
		fields.native_quic_mode = nativeQuicMode;
		nativeQuicMode.addEventListener('change', dirty);
		var nativeEndpointMode = E('select', { 'class': 'cbi-input-select', 'name': 'native_endpoint_mode' }, [
			E('option', { 'value': 'auto' }, [ _('Auto: Cloudflare registration endpoint') ]),
			E('option', { 'value': 'custom' }, [ _('Custom pool only') ]),
			E('option', { 'value': 'auto_custom' }, [ _('Auto, then custom fallback') ])
		]);
		fields.native_endpoint_mode = nativeEndpointMode;
		nativeEndpointMode.addEventListener('change', dirty);
		var batchSizeInput = makeInput('batch_size', 'number', { 'min': 1, 'max': 10, 'step': 1 });
		var nativeInterval = makeInput('native_min_interval', 'number', { 'min': 60, 'step': 1 });
		var nativeEndpoints = E('textarea', { 'rows': 4, 'class': 'cbi-input-text', 'style': 'width:100%; max-width:40em' });
		fields.native_endpoints = nativeEndpoints;
		nativeEndpoints.addEventListener('input', dirty);
		var refresh = makeInput('refresh_interval', 'number', { 'min': 60, 'step': 1 });
		var minimumReady = makeInput('minimum_ready', 'number', { 'min': 0, 'step': 1 });
		var healthInterval = makeInput('health_interval', 'number', { 'min': 5, 'step': 1 });
		var failureThreshold = makeInput('failure_threshold', 'number', { 'min': 1, 'step': 1 });
		var healthTimeout = makeInput('health_timeout', 'number', { 'min': 1, 'step': 1 });
		var strictHealth = makeInput('health_mode', 'checkbox', { 'class': 'cbi-input-checkbox' });
		var healthResolvers = makeInput('health_resolvers', 'text', {
			'placeholder': '1.1.1.1 8.8.8.8 9.9.9.9 77.88.8.8 77.88.8.1',
			'style': 'width:100%; max-width:40em'
		});
		var logLevel = E('select', { 'class': 'cbi-input-select', 'name': 'log_level' }, [
			E('option', { 'value': 'error' }, [ _('Error only') ]),
			E('option', { 'value': 'warning' }, [ _('Warnings and errors') ]),
			E('option', { 'value': 'info' }, [ _('Important events') ]),
			E('option', { 'value': 'debug' }, [ _('Debug: include successful health checks') ])
		]);
		var critical = E('textarea', {
			'name': 'critical_resource',
			'rows': 4,
			'class': 'cbi-input-text',
			'style': 'width:100%; max-width:40em'
		});
		var saveButton = E('button', {
			'class': 'btn cbi-button cbi-button-save',
			'click': L.bind(function(event) {
				event.preventDefault();
				return this.saveWarpAutoSettings();
			}, this)
		}, [ _('Save settings') ]);
		var generateButton = E('button', {
			'class': 'btn cbi-button cbi-button-action',
			'title': _('Acquire and test a batch of profiles using currently selected Provider (Remote generator or Native registration API)'),
			'click': L.bind(function(event) {
				event.preventDefault();
				return this.runWarpAutoAction('batch');
			}, this)
		}, [ _('Generate profiles (5)') ]);
		this.autoGenerateButton = generateButton;
		var refreshButton = E('button', {
			'class': 'btn cbi-button cbi-button-action',
			'title': _('Download latest remote configs or re-evaluate pool'),
			'click': L.bind(function(event) {
				event.preventDefault();
				return this.runWarpAutoAction('refresh');
			}, this)
		}, [ _('Refresh configs') ]);
		var testButton = E('button', {
			'class': 'btn cbi-button cbi-button-action',
			'title': _('Run probe tests on all profiles in the pool'),
			'click': L.bind(function(event) {
				event.preventDefault();
				return this.runWarpAutoAction('test_all');
			}, this)
		}, [ _('Test all') ]);
		var forceButton = E('button', {
			'class': 'btn cbi-button cbi-button-action',
			'title': _('Immediately replenish pool up to minimum READY count'),
			'click': L.bind(function(event) {
				event.preventDefault();
				return this.runWarpAutoAction('force_replenish');
			}, this)
		}, [ _('Force replenish') ]);
		var rollbackButton = E('button', {
			'class': 'btn cbi-button cbi-button-negative',
			'title': _('Revert network interface to previous profile'),
			'click': L.bind(function(event) {
				event.preventDefault();
				return this.runWarpAutoAction('rollback');
			}, this)
		}, [ _('Rollback') ]);
		var bootstrapButton = E('button', {
			'class': 'btn cbi-button cbi-button-positive',
			'disabled': true,
			'click': L.bind(function(event) {
				event.preventDefault();
				return this.runWarpAutoAction('bootstrap');
			}, this)
		}, [ _('Create WARP interface') ]);

		critical.addEventListener('input', dirty);
		critical.addEventListener('change', dirty);
		logLevel.addEventListener('change', dirty);

		this.autoFields = fields;
		this.autoFields.critical_resource = critical;
		this.autoFields.log_level = logLevel;
		this.autoSaveButton = saveButton;
		this.autoBootstrapButton = bootstrapButton;
		this.autoActionButtons = [ bootstrapButton, generateButton, refreshButton, testButton, forceButton, rollbackButton ];
		this.autoMessageNode = E('span', { 'style': 'margin-left:1em' });
		this.autoRuntimeNode = E('div', [ E('em', [ _('Loading WARP Auto status…') ]) ]);
		this.autoPoolNode = E('div', [ E('em', [ _('Loading WARP Auto pool…') ]) ]);
		this.autoLogsNode = E('div', [ E('em', [ _('Loading WARP Auto logs…') ]) ]);
		this.autoSettingsLoaded = false;
		this.autoSettingsDirty = false;
		this.autoBusy = false;
		this.remoteSettingsNode = E('div', [
			makeRow(_('Profile batch size'), batchSizeInput, _('Number of profiles acquired per batch generation (1..10, default 5).')),
			makeRow(_('Config source URL'), source, _('Default: %s. Change this for a mirror or compatible source.').format(DEFAULT_WARP_SOURCE_URL))
		]);

		// Native Provider Basic & Advanced Collapsible Section
		var nativeAdvancedToggle = E('a', {
			'href': '#',
			'style': 'font-weight:600; text-decoration:none; display:inline-block; margin:8px 0 12px 0;',
			'click': function(ev) {
				ev.preventDefault();
				var advNode = ev.target.nextElementSibling;
				var isHidden = advNode.style.display === 'none';
				advNode.style.display = isHidden ? '' : 'none';
				ev.target.innerText = isHidden ? _('▾ Hide Advanced Native Settings') : _('▸ Show Advanced Native Settings');
			}
		}, [ _('▸ Show Advanced Native Settings') ]);

		var nativeAdvancedSection = E('div', { 'style': 'display:none; padding-left:12px; border-left:2px solid var(--border-color-medium);' }, [
			makeRow(_('QUIC SNI'), nativeSni, _('Server Name Indication hostname encoded into dynamic QUIC I1.')),
			makeRow(_('QUIC mode'), nativeQuicMode, _('Dynamic local SNI I1 uses /usr/bin/quic-i1. Compatibility preset acts as error fallback if helper is unavailable.')),
			makeRow(_('Endpoint source'), nativeEndpointMode, _('Auto uses numeric endpoint returned by Cloudflare registration.')),
			makeRow(_('Minimum registration interval'), nativeInterval, _('Seconds between registration batches; failures use additional backoff.')),
			makeRow(_('Custom / Fallback Endpoint Pool'), nativeEndpoints, _('Optional host:port entries. Never treated as official Cloudflare endpoints; each must pass isolated health checks.'))
		]);

		this.nativeSettingsNode = E('div', [
			makeRow(_('Profile batch size'), batchSizeInput, _('Number of independent profiles registered and tested per batch (1..10, default 5).')),
			makeRow(_('Endpoint source'), nativeEndpointMode, _('Auto uses numeric endpoint returned by Cloudflare registration API.')),
			nativeAdvancedToggle,
			nativeAdvancedSection
		]);
		this.setWarpAutoSettings({});

		return this.renderWarpTabs([
			{
				id: 'overview',
				title: _('Overview'),
				content: [
					E('p', [ _('Runtime state, active connection details, and profile pool.') ]),
					this.autoRuntimeNode,
					E('h3', [ _('Profile Pool') ]),
					this.autoPoolNode,
					E('div', { 'class': 'cbi-page-actions', 'style': 'margin-top:16px;' }, [
						generateButton, ' ', refreshButton, ' ', testButton, ' ', forceButton, ' ', rollbackButton
					])
				]
			},
			{
				id: 'settings',
				title: _('Settings'),
				content: [
					E('h2', [ _('WARP Auto Settings') ]),

					// QUICK START MOVED TO TOP BEFORE CONFIGURATION SECTIONS
					E('div', {
						'class': 'cbi-section',
						'style': 'background-color:var(--background-color-low); border:1px solid var(--border-color-medium); border-left:4px solid var(--primary-color-medium, #0069d6); border-radius:4px; padding:12px 16px; margin-bottom:18px;'
					}, [
						E('h3', { 'style': 'margin:0 0 6px 0;' }, [ _('Quick Start') ]),
						E('p', { 'style': 'margin:0 0 10px 0; color:var(--text-color-medium); font-size:13px;' }, [
							_('Create and configure a dedicated WARP interface using tested profiles from the pool. Existing interfaces remain untouched.'),
							' ',
							E('a', {
								'href': '#',
								'style': 'font-weight:bold; margin-left:6px;',
								'click': L.bind(function(ev) {
									ev.preventDefault();
									this.switchWarpTab('amneziawg');
								}, this)
							}, [ _('View AmneziaWG Status →') ])
						]),
						E('div', [ bootstrapButton ])
					]),

					// SECTION 1: GENERAL
					E('div', { 'class': 'cbi-section', 'style': 'border:1px solid var(--border-color-medium); border-radius:4px; padding:12px 16px; margin-bottom:16px;' }, [
						E('h3', { 'style': 'margin-top:0; border-bottom:1px solid var(--border-color-low); padding-bottom:6px;' }, [ _('1. General Settings') ]),
						makeRow(_('Target AmneziaWG interface'), E('div', [
							target,
							' ',
							targetNew
						]), _('Choose existing interface, or enter a new name. Save before importing or using pool actions.')),
						makeRow(_('Enable WARP Auto'), enabled),
						makeRow(_('Provider'), provider)
					]),

					// SECTION 2: PROVIDER CONFIGURATION
					E('div', { 'class': 'cbi-section', 'style': 'border:1px solid var(--border-color-medium); border-radius:4px; padding:12px 16px; margin-bottom:16px;' }, [
						E('h3', { 'style': 'margin-top:0; border-bottom:1px solid var(--border-color-low); padding-bottom:6px;' }, [ _('2. Provider Configuration') ]),
						this.remoteSettingsNode,
						this.nativeSettingsNode
					]),

					// SECTION 3: POOL & FAILOVER
					E('div', { 'class': 'cbi-section', 'style': 'border:1px solid var(--border-color-medium); border-radius:4px; padding:12px 16px; margin-bottom:16px;' }, [
						E('h3', { 'style': 'margin-top:0; border-bottom:1px solid var(--border-color-low); padding-bottom:6px;' }, [ _('3. Pool & Failover Policy') ]),
						makeRow(_('Automatic failover'), failover, _('Only switches from ACTIVE after the configured consecutive failure threshold.')),
						makeRow(_('Failover cooldown'), failoverCooldown, _('Seconds before another automatic switch; default 10.')),
						makeRow(_('Minimum READY profiles'), minimumReady, _('Target count of ready standby profiles (default 2).')),
						makeRow(_('Refresh interval'), refresh, _('Seconds between routine pool checks; default 86400.'))
					]),

					// SECTION 4: HEALTH POLICY & LOGGING
					E('div', { 'class': 'cbi-section', 'style': 'border:1px solid var(--border-color-medium); border-radius:4px; padding:12px 16px; margin-bottom:16px;' }, [
						E('h3', { 'style': 'margin-top:0; border-bottom:1px solid var(--border-color-low); padding-bottom:6px;' }, [ _('4. Health Policy & Diagnostics') ]),
						makeRow(_('Health-check interval'), healthInterval, _('Seconds between runtime health checks; minimum 5; default 60.')),
						makeRow(_('Failure threshold'), failureThreshold, _('Consecutive failed checks to trigger failover; default 3.')),
						makeRow(_('Health-check timeout'), healthTimeout, _('Seconds to wait for health probe response; default 10.')),
						makeRow(_('Verify current Forkop/policy route'), strictHealth, _('Leave off on a bare router. Turn on after selected traffic is routed through Forkop.')),
						makeRow(_('Health-check DNS resolvers'), healthResolvers, _('Space-separated DNS resolvers for isolated candidate and health tests.')),
						makeRow(_('Log level'), logLevel, _('Important events by default. Select Debug only when diagnosing.')),
						makeRow(_('Critical resources'), critical, _('One hostname per line. youtube.com remains the default health target.'))
					]),

					// SAVE SETTINGS FINISHES CONFIGURATION FORM
					E('div', { 'class': 'cbi-page-actions' }, [ saveButton ])
				]
			},
			{
				id: 'amneziawg',
				title: _('AmneziaWG'),
				content: [ this.manualImporterNode, this.statusNode ]
			},
			{
				id: 'logs',
				title: _('Logs'),
				content: [
					E('p', [ _('Event log with structured severity levels and automatic secret redaction.') ]),
					this.autoLogsNode
				]
			}
		]);
	},

	handleImport: function(fileInput, button, resultNode) {
		var file = fileInput.files && fileInput.files[0];
		if (!file)
			return Promise.resolve();
		if (file.size > 65536) {
			dom.content(resultNode, E('span', { 'class': 'error' }, [ _('The file is larger than 64 KiB.') ]));
			return Promise.resolve();
		}

		button.disabled = true;
		dom.content(resultNode, E('em', [ _('Validating configuration…') ]));

		return readTextFile(file).then(L.bind(function(configText) {
			return callValidateAwgConfig(configText, file.name).then(L.bind(function(result) {
				if (!result || !result.ok)
					throw new Error(result && result.error || _('Configuration validation failed'));

				var iSummary = (result.i_fields || []).map(function(field) {
					return field.name.toUpperCase() + ' (' + field.length + ' chars)';
				}).join(', ') || _('none');

				ui.showModal(_('Apply AmneziaWG profile'), [
					E('p', [ _('The validated profile will replace selected target interface. Forkop and YT2 will not be restarted or modified.') ]),
					ui.itemlist(E([]), [
						_('Profile'), result.profile,
						_('Addresses'), (result.addresses || []).join(', '),
						_('Endpoint'), result.endpoint,
						_('Junk packets'), iSummary,
						_('Applied settings'), 'ListenPort 51821, fwmark 0x01000000, route_allowed_ips 0',
						_('Ignored settings'), 'DNS, ListenPort from file'
					]),
					E('div', { 'class': 'right' }, [
						E('button', {
							'class': 'btn',
							'click': ui.hideModal
						}, [ _('Cancel') ]),
						' ',
						E('button', {
							'class': 'btn cbi-button cbi-button-positive important',
							'click': L.bind(function(ev) {
								ev.currentTarget.disabled = true;
								dom.content(ev.currentTarget, [ _('Applying and testing…') ]);
								return callImportAwgConfig(configText, file.name).then(L.bind(function(applied) {
									ui.hideModal();
									if (!applied || !applied.ok)
										throw new Error(applied && applied.error || _('Import failed'));
									dom.content(resultNode, E('span', { 'style': 'color:green' }, [
										_('Active profile: %s (%s)').format(applied.profile, applied.endpoint)
									]));
									fileInput.value = '';
									ui.addNotification(null, E('p', [
										_('AmneziaWG profile applied. YouTube health check passed.')
									]), 'info');
									return callgetAwgInstances().then(L.bind(function(ifaces) {
										dom.content(this.statusNode, this.renderIfaces(ifaces));
									}, this));
								}, this)).catch(function(err) {
									ui.hideModal();
									throw err;
								});
							}, this)
						}, [ _('Apply to selected interface') ])
					])
				]);
			}, this));
		}, this)).catch(function(err) {
			dom.content(resultNode, E('span', { 'class': 'error' }, [ err.message ]));
			ui.addNotification(null, E('p', [ err.message ]), 'error');
		}).finally(function() {
			button.disabled = !(fileInput.files && fileInput.files.length);
		});
	},

	renderImporter: function() {
		var input = E('input', {
			'type': 'file',
			'accept': '.conf,text/plain'
		});
		var result = E('span', { 'style': 'margin-left:1em' });
		var button = E('button', {
			'class': 'btn cbi-button cbi-button-action',
			'disabled': true,
			'click': L.bind(function(ev) {
				ev.preventDefault();
				return this.handleImport(input, button, result);
			}, this)
		}, [ _('Validate and apply') ]);

		input.addEventListener('change', function() {
			button.disabled = !(input.files && input.files.length);
			dom.content(result, []);
		});

	return E('div', { 'class': 'cbi-section' }, [
			E('h2', [ _('Import AmneziaWG profile') ]),
			E('p', [
				_('Upload an AmneziaWG .conf file to replace selected target interface. The file is processed in memory and is not stored on the router.')
			]),
			E('div', { 'class': 'cbi-value' }, [
				E('label', { 'class': 'cbi-value-title' }, [ _('Configuration file') ]),
				E('div', { 'class': 'cbi-value-field' }, [ input, ' ', button, result ])
			]),
			E('p', { 'class': 'alert-message warning' }, [
				_('Only selected interface and its AmneziaWG peer are replaced. DNS is ignored; Forkop and other interfaces remain untouched.')
			])
		]);
	},

	renderIfaces: function(ifaces) {
		var res = [
			E('h2', [ _('AmneziaWG Status') ])
		];

		var ifaceCount = Object.keys(ifaces || {}).length;
		var totalPeers = 0;
		for (var k in ifaces) {
			if (Array.isArray(ifaces[k].peers)) totalPeers += ifaces[k].peers.length;
		}

		var summaryBar = E('div', {
			'style': 'display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; margin-bottom:14px; gap:8px; background-color:var(--background-color-low); padding:8px 12px; border-radius:4px; border:1px solid var(--border-color-medium);'
		}, [
			E('div', [
				E('strong', [ _('Interfaces:') ]), ' ' + ifaceCount + ' · ',
				E('strong', [ _('Total Peers:') ]), ' ' + totalPeers
			]),
			E('div', [
				this.profileDownload('active', _('Download Active Profile (.conf)'))
			])
		]);
		res.push(summaryBar);

		for (var instanceName in ifaces) {
			res.push(
				E('h3', [ _('Instance "%h"', 'AmneziaWG instance heading').format(instanceName) ]),
				E('p', {
					'style': 'cursor:pointer',
					'click': ui.createHandlerFn(this, handleInterfaceDetails, ifaces[instanceName])
				}, [
					E('span', { 'class': 'ifacebadge' }, [
						E('img', { 'src': L.resource('icons', 'amneziawg.svg') }),
						'\xa0',
						instanceName
					]),
					E('span', { 'style': 'opacity:.8' }, [
						' · ',
						_('Port %d', 'AmneziaWG listen port').format(ifaces[instanceName].listen_port),
						' · ',
						E('code', { 'click': '' }, [ ifaces[instanceName].public_key ])
					])
				]),
				renderPeerTable(instanceName, ifaces[instanceName].peers)
			);
		}

		if (res.length == 2 && ifaceCount == 0)
			res.push(E('p', { 'class': 'center', 'style': 'margin-top:3em' }, [
				E('em', [ _('No AmneziaWG interfaces configured.') ])
			]));

		return E([], res);
	},

	render: function() {
		this.statusNode = E('div', [
			E('h2', [ _('AmneziaWG Status') ]),
			E('p', { 'class': 'center', 'style': 'margin-top:5em' }, [
				E('em', [ _('Loading data…') ])
			])
		]);
		this.manualImporterNode = this.renderImporter();
		this.warpAutoNode = this.renderWarpAuto();
		this.updateWarpAuto();

		poll.add(L.bind(function () {
			return callgetAwgInstances().then(L.bind(function(ifaces) {
				dom.content(this.statusNode, this.renderIfaces(ifaces));
			}, this));
		}, this), 5);

		poll.add(L.bind(function() {
			return this.updateWarpAuto();
		}, this), 5);

		return this.warpAutoNode;
	},

	handleReset: null,
	handleSaveApply: null,
	handleSave: null
});
